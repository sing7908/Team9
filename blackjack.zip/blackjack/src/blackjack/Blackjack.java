/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.FlowPane;
import javafx.stage.Stage;
import javax.swing.JOptionPane;


/**
 *
 * @author Narinder
 */
public class Blackjack extends Application {
    
    
        ArrayList<Card> deck = new ArrayList<Card>();
ArrayList<Card> playerPile = new ArrayList<Card>();
ArrayList<Card> dealerPile = new ArrayList<Card>();
   private FlowPane playerPanel;
	private FlowPane dealerPanel;
  @Override
    public void start(Stage primaryStage) {
        try {
			BorderPane root = new BorderPane();
			Scene scene = new Scene(root, 500, 500);
		
			primaryStage.setScene(scene);
			primaryStage.show();
			primaryStage.setTitle("BlackJack");
                       
			dealerPanel = new FlowPane();
			dealerPanel.setAlignment(Pos.CENTER);
			root.setTop(dealerPanel);
			playerPanel = new FlowPane();
			playerPanel.setAlignment(Pos.CENTER);
			root.setCenter(playerPanel);

			FlowPane buttonsPanel = new FlowPane();
			buttonsPanel.setAlignment(Pos.CENTER);
			Button hitButton = new Button("Hit");
			Button stayButton = new Button("Stay");
			buttonsPanel.getChildren().add(hitButton);
			buttonsPanel.getChildren().add(stayButton);
			root.setBottom(buttonsPanel);
			
			InitDeck();
			dealToDealer();
			dealToPlayer();
			dealToDealer();
			dealToPlayer();
			
			hitButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
					dealToPlayer();
					if(PlayerIsBusted()){
						JOptionPane.showMessageDialog(null, "Over 21! Game over");
					}
				}
			});

			stayButton.setOnAction(new EventHandler<ActionEvent>() {
				@Override
				public void handle(ActionEvent e) {
			      //dealToDealer();
				
		while(dealersum()<16 && dealersum()<playersum())
			{
				dealToDealer();
					}
                          if( DealerIsBusted()){
                    	JOptionPane.showMessageDialog(null, "Over 21! Game over,Dealer is busted");
                    						
                    	}
                                        
                                        	
                   else if(dealersum()>playersum()) {
                       JOptionPane.showMessageDialog(null, "Dealer win!!");
                                        		
                      }else {
                         JOptionPane.showMessageDialog(null, "Player wins");
                            }
                                            
				}
			});

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
   
	
	private boolean PlayerIsBusted() {
		int playerSum = 0;
		          for (int i = 0; i < playerPile.size(); i++) {
                Card c = playerPile.get(i);
                playerSum += c.getBlackJackValue();
            }
                        
		if (playerSum > 21) 
			return true;
		 
		return false;
	}
        private boolean DealerIsBusted() {
		int dealerSum = 0;
		  for (int i = 0; i < dealerPile.size(); i++) {
                Card c = dealerPile.get(i);
                dealerSum += c.getBlackJackValue();
            }
		
		if (dealerSum > 21) 
			return true;
		 
		return false;
	}
       private int playersum() {
        	
        	int playerSum = 0;
            for(int i=0;i<playerPile.size();i++){
                Card c=playerPile.get(i);
                playerSum+=c.getBlackJackValue();
            }
            return playerSum;
        }
       
        private int dealersum() {
        	int dealerSum=0;
        	for(int i=0;i<dealerPile.size();i++){
                Card c=dealerPile.get(i);
                dealerSum+=c.getBlackJackValue();
            }
        	return dealerSum;
        }

	private void InitDeck() {
		String[] suits = new String[] { "hearts", "diamonds", "clubs", "spades" };

		for (String s : suits) {
			for (int i = 1; i < 14; i++) {
                           
				Card c = new Card(i, s);
				deck.add(c);
			}
		}
	}
	
	private void dealToDealer(){
		Card c = deck.remove(0);
		dealerPile.add(c);
		DisplayCard(c, dealerPanel);
	}
	
	private void dealToPlayer(){
		Card c = deck.remove(0);
		playerPile.add(c);
		DisplayCard(c, playerPanel);
	}
	
	private void DisplayCard(Card c, FlowPane panel) {
		Image img = new Image("cards/" + c.GetFileName());
		ImageView viewer = new ImageView(img);
		panel.getChildren().add(viewer);
		viewer.setPreserveRatio(true);
		viewer.setFitWidth(100);
	}
	


    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
