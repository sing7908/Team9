/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package blackjack;

/**
 *
 * @author Narinder
 */
public class Card {
    
    int rank; 
    String suit; 
    
    public Card(int r, String s){
        rank = r;
        suit = s;
    }
    public String GetFileName(){
        return rank + "_of_" + suit + ".png";
    }
    public int getBlackJackValue(){
        if (rank< 10)
            return rank;
        else return 10;
    }

}
